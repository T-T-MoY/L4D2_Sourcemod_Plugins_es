//************************************************************************
// L4D2 Chat Publicity
// Versión 1.1 - Corregida para SourceMod 1.12
//************************************************************************

#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <multicolors>

#define PLUGIN_VERSION "1.1"

public Plugin myinfo = 
{
	name = "[L4D2] Chat Publicity",
	author = "Foxhound27",
	description = "Displays colored publicity as chat message",
	version = PLUGIN_VERSION,
	url = ""
};

ConVar g_cvTime;
KeyValues g_kvFile = null;
Handle g_hTimer = null;

public void OnPluginStart() 
{
	// Verificar que sea L4D2
	char sGameFolder[24];
	GetGameFolderName(sGameFolder, sizeof(sGameFolder));
	
	if (!StrEqual(sGameFolder, "left4dead2", false))
	{
		SetFailState("Este plugin solo funciona en Left 4 Dead 2");
	}
	
	// Crear ConVar
	g_cvTime = CreateConVar("l4d2_publicity_time", "120", "Tiempo en segundos entre cada mensaje de publicidad", FCVAR_NOTIFY, true, 10.0);
	g_cvTime.AddChangeHook(OnCvarChange);
	
	AutoExecConfig(true, "l4d2_chat_publicity");
	
	// Cargar archivo de configuración
	LoadPublicityFile();
}

public void OnCvarChange(ConVar convar, const char[] oldValue, const char[] newValue)
{
	if (convar == g_cvTime)
	{
		// Recrear el timer con el nuevo tiempo
		delete g_hTimer;
		g_hTimer = CreateTimer(g_cvTime.FloatValue, Timer_DisplayPublicity, _, TIMER_REPEAT);
	}
}

public void OnMapStart()
{
	// Reiniciar el KeyValues al principio del mapa
	LoadPublicityFile();
	
	// Crear el timer
	delete g_hTimer;
	g_hTimer = CreateTimer(g_cvTime.FloatValue, Timer_DisplayPublicity, _, TIMER_REPEAT);
}

public void OnMapEnd()
{
	// Matar el timer al final del mapa
	delete g_hTimer;
}

public void OnPluginEnd()
{
	// Limpiar recursos
	delete g_hTimer;
	delete g_kvFile;
}

void LoadPublicityFile()
{
	char sFilePath[PLATFORM_MAX_PATH];
	BuildPath(Path_SM, sFilePath, sizeof(sFilePath), "data/l4d2_publicity.txt");
	
	// Limpiar KeyValues anterior si existe
	delete g_kvFile;
	
	// Crear nuevo KeyValues
	g_kvFile = new KeyValues("publicity");
	
	// Intentar cargar el archivo
	if (!FileExists(sFilePath))
	{
		LogError("[Publicity] Archivo no encontrado: %s", sFilePath);
		LogError("[Publicity] Creando archivo de ejemplo...");
		CreateExampleFile(sFilePath);
		return;
	}
	
	if (!g_kvFile.ImportFromFile(sFilePath))
	{
		LogError("[Publicity] Error al cargar el archivo: %s", sFilePath);
		return;
	}
	
	// Ir a la primera entrada
	if (!g_kvFile.GotoFirstSubKey())
	{
		LogError("[Publicity] No se encontraron mensajes en el archivo de configuración");
		return;
	}
	
	LogMessage("[Publicity] Archivo de publicidad cargado correctamente");
}

void CreateExampleFile(const char[] path)
{
	KeyValues kv = new KeyValues("publicity");
	
	kv.JumpToKey("msg1", true);
	kv.SetString("msg", "{green}Bienvenido a nuestro servidor de L4D2!");
	kv.GoBack();
	
	kv.JumpToKey("msg2", true);
	kv.SetString("msg", "{lightgreen}Visita nuestro Discord: {olive}discord.gg/ejemplo");
	kv.GoBack();
	
	kv.JumpToKey("msg3", true);
	kv.SetString("msg", "{blue}Recuerda leer las {red}reglas {blue}del servidor!");
	kv.GoBack();
	
	kv.JumpToKey("msg4", true);
	kv.SetString("msg", "{purple}¿Necesitas ayuda? Escribe {olive}!help {purple}en el chat");
	kv.GoBack();
	
	kv.Rewind();
	kv.ExportToFile(path);
	delete kv;
	
	LogMessage("[Publicity] Archivo de ejemplo creado en: %s", path);
}

public Action Timer_DisplayPublicity(Handle timer)
{
	if (g_kvFile == null)
	{
		LogError("[Publicity] KeyValues no está inicializado");
		return Plugin_Continue;
	}
	
	char sMessage[256];
	g_kvFile.GetString("msg", sMessage, sizeof(sMessage), "");
	
	// Verificar que el mensaje no esté vacío
	if (sMessage[0] != '\0')
	{
		// Usar CPrintToChatAll de multicolors que respeta otros plugins
		CPrintToChatAll("%s", sMessage);
	}
	
	// Ir al siguiente mensaje
	GoToNextKeyOrStartOver();
	
	return Plugin_Continue;
}

void GoToNextKeyOrStartOver()
{
	if (g_kvFile == null)
		return;
	
	// Intentar ir a la siguiente clave
	if (!g_kvFile.GotoNextKey())
	{
		// Si no hay más, volver al inicio
		g_kvFile.Rewind();
		
		if (!g_kvFile.GotoFirstSubKey())
		{
			LogError("[Publicity] No se pudo volver al primer mensaje");
		}
	}
}