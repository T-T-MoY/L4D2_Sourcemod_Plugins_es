//************************************************************************
// Simple Chat Colors Bridge for Chat-Processor
// Versión 1.4 - Optimizada para SourceMod 1.12
//************************************************************************

#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <multicolors>
#include <chat-processor>

#define PLUGIN_VERSION "1.4"
#define CONFIG_PATH "configs/simple-chatcolors.cfg"

public Plugin myinfo =
{
	name = "Simple Chat Colors Bridge",
	author = "Converted & Fixed",
	description = "Reads old SCC configs and applies them via Chat-Processor",
	version = PLUGIN_VERSION,
	url = ""
};

// Variables globales
bool g_bLateLoad = false;

// Almacenar configuración de cada cliente
char g_sClientTag[MAXPLAYERS+1][128];
char g_sClientTagColor[MAXPLAYERS+1][32];
char g_sClientNameColor[MAXPLAYERS+1][32];
char g_sClientTextColor[MAXPLAYERS+1][32];
bool g_bClientHasConfig[MAXPLAYERS+1];

public APLRes AskPluginLoad2(Handle myself, bool late, char[] error, int err_max)
{
	g_bLateLoad = late;
	return APLRes_Success;
}

public void OnPluginStart()
{
	// ConVars
	CreateConVar("scc_bridge_version", PLUGIN_VERSION, "SCC Bridge Version", FCVAR_NOTIFY|FCVAR_DONTRECORD);
	
	// Comandos de administración
	RegAdminCmd("sm_reloadscc", Command_Reload, ADMFLAG_CONFIG, "Reloads Simple Chat Colors config");
	RegAdminCmd("sm_printcolors", Command_PrintColors, ADMFLAG_GENERIC, "Prints available color codes");
	
	// Si el plugin se cargó tarde, aplicar configuración a los jugadores actuales
	if (g_bLateLoad)
	{
		for (int i = 1; i <= MaxClients; i++)
		{
			if (IsClientInGame(i) && !IsFakeClient(i) && IsClientAuthorized(i))
			{
				LoadPlayerSettings(i);
			}
		}
	}
}

public void OnClientPostAdminCheck(int client)
{
	if (!IsFakeClient(client))
	{
		LoadPlayerSettings(client);
	}
}

public void OnClientDisconnect(int client)
{
	// Limpia la configuración del jugador al desconectarse
	ResetClientSettings(client);
	g_bClientHasConfig[client] = false;
}

//====================================
// Comandos
//====================================

public Action Command_Reload(int client, int args)
{
	int reloadCount = 0;
	
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && !IsFakeClient(i) && IsClientAuthorized(i))
		{
			LoadPlayerSettings(i);
			reloadCount++;
		}
	}
	
	CReplyToCommand(client, "{green}[SCC]{default} Configuración recargada para {olive}%d{default} jugadores.", reloadCount);
	
	if (client > 0)
	{
		LogAction(client, -1, "\"%L\" recargó la configuración de Simple Chat Colors (%d jugadores afectados)", client, reloadCount);
	}
	else
	{
		LogAction(client, -1, "La consola recargó la configuración de Simple Chat Colors (%d jugadores afectados)", reloadCount);
	}
	
	return Plugin_Handled;
}

public Action Command_PrintColors(int client, int args)
{
	if (client == 0)
	{
		ReplyToCommand(client, "[SCC] Este comando debe ser usado en el juego.");
		return Plugin_Handled;
	}

	CPrintToChat(client, "{green}=== Colores Disponibles ==={default}");
	CPrintToChat(client, "{default}{default} - Default/Blanco");
	CPrintToChat(client, "{green}{green} - Verde");
	CPrintToChat(client, "{lightgreen}{lightgreen} - Verde Claro");
	CPrintToChat(client, "{red}{red} - Rojo (Infectados)");
	CPrintToChat(client, "{blue}{blue} - Azul (Supervivientes)");
	CPrintToChat(client, "{olive}{olive} - Oliva");
	CPrintToChat(client, "{orange}{orange} - Naranja");
	CPrintToChat(client, "{purple}{purple} - Morado");
	CPrintToChat(client, "{teamcolor}{teamcolor} - Color de tu equipo");
	
	return Plugin_Handled;
}

//====================================
// Chat-Processor Forwards
//====================================

public Action OnChatMessage(int &author, Handle recipients, char[] name, char[] message)
{
	// Solo procesar si el autor tiene configuración
	if (!g_bClientHasConfig[author])
		return Plugin_Continue;
	
	// No modificar mensajes del sistema o comandos
	if (author <= 0 || message[0] == '!' || message[0] == '/')
		return Plugin_Continue;
	
	return Plugin_Continue;
}

//====================================
// Funciones principales
//====================================

void LoadPlayerSettings(int client)
{
	if (!IsValidClient(client))
		return;
	
	char sConfigPath[PLATFORM_MAX_PATH];
	BuildPath(Path_SM, sConfigPath, sizeof(sConfigPath), CONFIG_PATH);
	
	if (!FileExists(sConfigPath))
	{
		LogMessage("[SCC] Archivo de configuración no encontrado: %s", sConfigPath);
		return;
	}
	
	KeyValues kv = new KeyValues("admin_colors");
	
	if (!kv.ImportFromFile(sConfigPath))
	{
		LogError("[SCC] Fallo al leer el archivo de configuración: %s", sConfigPath);
		delete kv;
		return;
	}
	
	if (!kv.GotoFirstSubKey())
	{
		LogError("[SCC] No se encontraron secciones en el archivo de configuración");
		delete kv;
		return;
	}
	
	char sSteamID[64];
	if (!GetClientAuthId(client, AuthId_Steam2, sSteamID, sizeof(sSteamID)))
	{
		LogError("[SCC] No se pudo obtener el SteamID del cliente %N", client);
		delete kv;
		return;
	}
	
	bool bFound = false;
	
	// Buscar configuración específica para el jugador
	do
	{
		char sSectionName[64];
		kv.GetSectionName(sSectionName, sizeof(sSectionName));
		
		// Verificar por SteamID directo
		if (StrContains(sSectionName, "STEAM_", false) == 0)
		{
			if (StrEqual(sSectionName, sSteamID, false))
			{
				ApplyPlayerSettings(client, kv);
				bFound = true;
				break;
			}
		}
		// Verificar por flags de administrador
		else
		{
			char sFlags[32];
			kv.GetString("flag", sFlags, sizeof(sFlags));
			
			if (sFlags[0] != '\0')
			{
				if (CheckClientFlags(client, sFlags))
				{
					ApplyPlayerSettings(client, kv);
					bFound = true;
					break;
				}
			}
		}
	}
	while (kv.GotoNextKey());
	
	delete kv;
	
	// Si no se encontró configuración, resetear
	if (!bFound)
	{
		ResetClientSettings(client);
		g_bClientHasConfig[client] = false;
	}
}

void ApplyPlayerSettings(int client, KeyValues kv)
{
	// Leer configuración del KeyValues
	kv.GetString("tag", g_sClientTag[client], sizeof(g_sClientTag[]), "");
	kv.GetString("tagcolor", g_sClientTagColor[client], sizeof(g_sClientTagColor[]), "");
	kv.GetString("namecolor", g_sClientNameColor[client], sizeof(g_sClientNameColor[]), "");
	kv.GetString("textcolor", g_sClientTextColor[client], sizeof(g_sClientTextColor[]), "");
	
	// Marcar que este cliente tiene configuración
	g_bClientHasConfig[client] = (g_sClientTag[client][0] != '\0' || 
	                               g_sClientNameColor[client][0] != '\0' || 
	                               g_sClientTextColor[client][0] != '\0');
	
	// Limpiar configuración anterior
	ChatProcessor_StripClientTags(client);
	
	// Aplicar tag si existe
	if (g_sClientTag[client][0] != '\0')
	{
		char sFullTag[256];
		
		if (g_sClientTagColor[client][0] != '\0')
		{
			// Normalizar el color para asegurar compatibilidad
			char sNormalizedColor[32];
			NormalizeColorTag(g_sClientTagColor[client], sNormalizedColor, sizeof(sNormalizedColor));
			
			// Si hay color de tag, aplicarlo
			FormatEx(sFullTag, sizeof(sFullTag), "%s%s{default} ", sNormalizedColor, g_sClientTag[client]);
		}
		else
		{
			// Sin color específico, usar default
			FormatEx(sFullTag, sizeof(sFullTag), "%s ", g_sClientTag[client]);
		}
		
		ChatProcessor_AddClientTag(client, sFullTag);
	}
	
	// Aplicar colores de nombre y texto
	if (g_sClientNameColor[client][0] != '\0')
	{
		char sNormalizedNameColor[32];
		NormalizeColorTag(g_sClientNameColor[client], sNormalizedNameColor, sizeof(sNormalizedNameColor));
		ChatProcessor_SetNameColor(client, sNormalizedNameColor);
	}
	else
	{
		ChatProcessor_SetNameColor(client, "");
	}
	
	if (g_sClientTextColor[client][0] != '\0')
	{
		char sNormalizedTextColor[32];
		NormalizeColorTag(g_sClientTextColor[client], sNormalizedTextColor, sizeof(sNormalizedTextColor));
		ChatProcessor_SetChatColor(client, sNormalizedTextColor);
	}
	else
	{
		ChatProcessor_SetChatColor(client, "");
	}
}

void ResetClientSettings(int client)
{
	ChatProcessor_StripClientTags(client);
	ChatProcessor_SetNameColor(client, "");
	ChatProcessor_SetChatColor(client, "");
	
	g_sClientTag[client][0] = '\0';
	g_sClientTagColor[client][0] = '\0';
	g_sClientNameColor[client][0] = '\0';
	g_sClientTextColor[client][0] = '\0';
}

//====================================
// Funciones auxiliares
//====================================

void NormalizeColorTag(const char[] input, char[] output, int maxlen)
{
	// Copiar el input al output
	strcopy(output, maxlen, input);
	
	// Asegurar que el color tenga llaves
	if (output[0] != '{')
	{
		char temp[32];
		strcopy(temp, sizeof(temp), output);
		FormatEx(output, maxlen, "{%s}", temp);
	}
	
	// Convertir a minúsculas para consistencia
	for (int i = 0; output[i] != '\0'; i++)
	{
		output[i] = CharToLower(output[i]);
	}
}

bool CheckClientFlags(int client, const char[] flagString)
{
	AdminId admin = GetUserAdmin(client);
	
	if (admin == INVALID_ADMIN_ID)
		return false;
	
	int requiredFlags = ReadFlagString(flagString);
	
	if (requiredFlags == 0)
		return false;
	
	// Obtener los flags del admin con Access_Effective
	// Esto incluye tanto flags directos como heredados de grupos
	int adminFlags = admin.GetFlags(Access_Effective);
	
	// Verificar si el admin tiene TODOS los flags requeridos
	return (adminFlags & requiredFlags) == requiredFlags;
}

bool IsValidClient(int client)
{
	return (client > 0 && client <= MaxClients && IsClientInGame(client) && !IsFakeClient(client) && IsClientAuthorized(client));
}