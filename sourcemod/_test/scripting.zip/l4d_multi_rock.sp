#include <sourcemod>
#include <sdkhooks>
#include <sdktools>

#define PLUGIN_VERSION "2.1"
#define ZOMBIECLASS_TANK 8

public Plugin myinfo = 
{
    name = "Tank Multi-Rock L4D2",
    author = "Pan Xiaohai - Modificado",
    description = "Tank lanza múltiples rocas al lanzar su roca habitual",
    version = PLUGIN_VERSION,
    url = ""
}

ConVar g_cvEnable;
ConVar g_cvChance;
ConVar g_cvDamage;
ConVar g_cvMinRocks;
ConVar g_cvMaxRocks;

bool g_bTankImmune[MAXPLAYERS + 1];
Handle g_hImmunityTimer[MAXPLAYERS + 1];

public void OnPluginStart()
{
    g_cvEnable = CreateConVar("l4d_multi_rock_enable", "1", "0:deshabilitado, 1:habilitado en coop, 2: habilitado en todos los modos", FCVAR_NOTIFY, true, 0.0, true, 2.0);
    g_cvChance = CreateConVar("l4d_multi_rock_chance_throw", "25.0", "Probabilidad de lanzar múltiples rocas [0.0, 100.0]", FCVAR_NOTIFY, true, 0.0, true, 100.0);
    g_cvDamage = CreateConVar("l4d_multi_rock_damage", "20", "Daño de las rocas adicionales [1.0, 100.0]", FCVAR_NOTIFY, true, 1.0, true, 100.0);
    g_cvMinRocks = CreateConVar("l4d_multi_rock_min", "1", "Mínimo de rocas adicionales", FCVAR_NOTIFY, true, 1.0, true, 5.0);
    g_cvMaxRocks = CreateConVar("l4d_multi_rock_max", "2", "Máximo de rocas adicionales", FCVAR_NOTIFY, true, 1.0, true, 5.0);
    
    AutoExecConfig(true, "l4d_multi_rock");
    
    HookEvent("ability_use", Event_AbilityUse);
    HookEvent("player_death", Event_PlayerDeath);
    HookEvent("round_start", Event_RoundStart);
}

public Action Event_AbilityUse(Event event, const char[] name, bool dontBroadcast)
{   
    if(!CanUsePlugin()) 
        return Plugin_Continue;
    
    int client = GetClientOfUserId(event.GetInt("userid"));
    if(!IsValidClient(client) || !IsPlayerAlive(client))
        return Plugin_Continue;
    
    if(GetClientTeam(client) != 3 || GetEntProp(client, Prop_Send, "m_zombieClass") != ZOMBIECLASS_TANK)
        return Plugin_Continue;
    
    char ability[32];
    event.GetString("ability", ability, sizeof(ability));
    
    if(StrEqual(ability, "ability_throw", true))
    {   
        float random = GetRandomFloat(0.0, 100.0);
        if(random < g_cvChance.FloatValue)
        {  
            // Activar inmunidad del Tank durante la animación de lanzamiento
            g_bTankImmune[client] = true;
            SDKHook(client, SDKHook_OnTakeDamage, Hook_TankTakeDamage);
            
            // Aplicar glow al Tank
            SetEntProp(client, Prop_Send, "m_iGlowType", 3);
            SetEntProp(client, Prop_Send, "m_nGlowRange", 0);
            SetEntProp(client, Prop_Send, "m_nGlowRangeMin", 10);
            SetEntProp(client, Prop_Send, "m_glowColorOverride", 25600); // Verde brillante
            
            // Lanzar rocas múltiples después de un breve delay
            CreateTimer(0.5, Timer_MultiRock, GetClientUserId(client), TIMER_FLAG_NO_MAPCHANGE);
            
            // Quitar el glow después de 3 segundos
            CreateTimer(3.0, Timer_RemoveGlow, GetClientUserId(client), TIMER_FLAG_NO_MAPCHANGE);
            
            // Quitar inmunidad después de la animación completa (2.5 segundos es la duración aproximada del lanzamiento)
            if(g_hImmunityTimer[client] != null)
            {
                KillTimer(g_hImmunityTimer[client]);
                g_hImmunityTimer[client] = null;
            }
            g_hImmunityTimer[client] = CreateTimer(2.5, Timer_RemoveImmunity, GetClientUserId(client), TIMER_FLAG_NO_MAPCHANGE);
            
            // Mensaje de alerta
            PrintToChatAll("\x04[Multi-Rock] \x05¡El Tank va a lanzar múltiples rocas!");
        }
    }
    
    return Plugin_Continue;
}

public Action Timer_RemoveGlow(Handle timer, any userid)
{
    int client = GetClientOfUserId(userid);
    if(IsValidClient(client) && IsPlayerAlive(client))
    {
        SetEntProp(client, Prop_Send, "m_iGlowType", 0);
        SetEntProp(client, Prop_Send, "m_nGlowRange", 0);
        SetEntProp(client, Prop_Send, "m_nGlowRangeMin", 0);
        SetEntProp(client, Prop_Send, "m_glowColorOverride", 0);
    }
    return Plugin_Stop;
}

public Action Timer_RemoveImmunity(Handle timer, any userid)
{
    int client = GetClientOfUserId(userid);
    if(IsValidClient(client))
    {
        g_bTankImmune[client] = false;
        g_hImmunityTimer[client] = null;
        SDKUnhook(client, SDKHook_OnTakeDamage, Hook_TankTakeDamage);
    }
    return Plugin_Stop;
}

public Action Hook_TankTakeDamage(int victim, int &attacker, int &inflictor, float &damage, int &damagetype)
{
    // Si el Tank tiene inmunidad activa, bloquear todo daño
    if(g_bTankImmune[victim])
    {
        return Plugin_Handled;
    }
    
    return Plugin_Continue;
}

public Action Event_PlayerDeath(Event event, const char[] name, bool dontBroadcast)
{
    int client = GetClientOfUserId(event.GetInt("userid"));
    if(IsValidClient(client))
    {
        g_bTankImmune[client] = false;
        if(g_hImmunityTimer[client] != null)
        {
            KillTimer(g_hImmunityTimer[client]);
            g_hImmunityTimer[client] = null;
        }
        SDKUnhook(client, SDKHook_OnTakeDamage, Hook_TankTakeDamage);
    }
    return Plugin_Continue;
}

public Action Event_RoundStart(Event event, const char[] name, bool dontBroadcast)
{
    for(int i = 1; i <= MaxClients; i++)
    {
        g_bTankImmune[i] = false;
        if(g_hImmunityTimer[i] != null)
        {
            KillTimer(g_hImmunityTimer[i]);
            g_hImmunityTimer[i] = null;
        }
    }
    return Plugin_Continue;
}

public Action Timer_MultiRock(Handle timer, any userid)
{ 
    int client = GetClientOfUserId(userid);
    if(!IsValidClient(client) || !IsPlayerAlive(client))
        return Plugin_Stop;
    
    if(GetClientTeam(client) != 3 || GetEntProp(client, Prop_Send, "m_zombieClass") != ZOMBIECLASS_TANK)
        return Plugin_Stop;
    
    float eyePos[3];
    GetClientEyePosition(client, eyePos);
    
    LaunchMultipleRocks(client, eyePos);
    
    return Plugin_Stop;
}

void LaunchMultipleRocks(int client, float eyePos[3])
{  
    // Obtener límites configurados
    int minRocks = g_cvMinRocks.IntValue;
    int maxRocks = g_cvMaxRocks.IntValue;
    
    // Asegurar límites válidos
    if(minRocks < 1) minRocks = 1;
    if(maxRocks > 5) maxRocks = 5;
    if(minRocks > maxRocks) maxRocks = minRocks;
    
    int additionalRocks = GetRandomInt(minRocks, maxRocks);
    
    // Obtener supervivientes vivos
    int survivors[MAXPLAYERS + 1];
    int survivorCount = 0;
    
    for(int i = 1; i <= MaxClients; i++)
    {
        if(IsClientInGame(i) && GetClientTeam(i) == 2 && IsPlayerAlive(i))
        {
            survivors[survivorCount++] = i;
        }
    }
    
    if(survivorCount == 0) 
        return;
    
    char damageStr[32];
    g_cvDamage.GetString(damageStr, sizeof(damageStr));
    
    // Obtener dirección hacia donde mira el Tank
    float tankAngles[3];
    GetClientEyeAngles(client, tankAngles);
    
    // Lanzar rocas adicionales
    for(int rock = 0; rock < additionalRocks; rock++)
    {
        int target = survivors[GetRandomInt(0, survivorCount - 1)];
        
        if(!IsClientInGame(target) || !IsPlayerAlive(target))
            continue;
        
        float targetPos[3];
        GetClientEyePosition(target, targetPos);
        
        float direction[3];
        SubtractVectors(targetPos, eyePos, direction);
        NormalizeVector(direction, direction);
        
        // Añadir dispersión aleatoria para variación
        direction[0] += GetRandomFloat(-0.15, 0.15);
        direction[1] += GetRandomFloat(-0.15, 0.15);
        direction[2] += GetRandomFloat(-0.1, 0.1);
        
        NormalizeVector(direction, direction);
        
        // IMPORTANTE: Spawn de la roca MUY ADELANTE del Tank (300 unidades)
        // Esto evita que choque con el Tank o se atasque
        float launchPos[3];
        launchPos[0] = eyePos[0] + (direction[0] * 300.0);
        launchPos[1] = eyePos[1] + (direction[1] * 300.0);
        launchPos[2] = eyePos[2] + (direction[2] * 300.0);
        
        int ent = CreateEntityByName("env_rock_launcher");
        
        if(!IsValidEntity(ent))
            continue;
        
        DispatchKeyValue(ent, "rockdamageoverride", damageStr);
        DispatchSpawn(ent);
        
        // Teleportar la entidad lanzadora ADELANTE del Tank
        TeleportEntity(ent, launchPos, NULL_VECTOR, NULL_VECTOR);
        
        // Asignar objetivo
        SetVariantEntity(target);
        AcceptEntityInput(ent, "SetTarget");
        
        // Lanzar la roca con un pequeño delay escalonado para mejor efecto visual
        DataPack pack;
        CreateDataTimer(0.05 * rock, Timer_LaunchRock, pack, TIMER_FLAG_NO_MAPCHANGE);
        pack.WriteCell(EntIndexToEntRef(ent));
        pack.WriteCell(GetClientUserId(target));
    }
}

public Action Timer_LaunchRock(Handle timer, DataPack pack)
{
    pack.Reset();
    int entRef = pack.ReadCell();
    int userid = pack.ReadCell();
    
    int ent = EntRefToEntIndex(entRef);
    int target = GetClientOfUserId(userid);
    
    if(ent != INVALID_ENT_REFERENCE && IsValidEntity(ent))
    {
        if(IsValidClient(target) && IsPlayerAlive(target))
        {
            SetVariantEntity(target);
            AcceptEntityInput(ent, "SetTarget");
        }
        
        AcceptEntityInput(ent, "LaunchRock");
        CreateTimer(0.1, Timer_RemoveLauncher, EntIndexToEntRef(ent), TIMER_FLAG_NO_MAPCHANGE);
    }
    
    return Plugin_Stop;
}

public Action Timer_RemoveLauncher(Handle timer, any entRef)
{
    int ent = EntRefToEntIndex(entRef);
    if(ent != INVALID_ENT_REFERENCE && IsValidEntity(ent))
    {
        AcceptEntityInput(ent, "Kill");
    }
    return Plugin_Stop;
}

bool CanUsePlugin()
{
    int mode = g_cvEnable.IntValue;
    if(mode == 0) 
        return false;
    
    if(mode == 1)
    {
        int gameMode = GetCurrentGameMode();
        if(gameMode == 2) // Versus
            return false;
    }
    
    return true;
}

int GetCurrentGameMode()
{
    char gameMode[32];
    ConVar cvGameMode = FindConVar("mp_gamemode");
    
    if(cvGameMode == null)
        return 0;
    
    cvGameMode.GetString(gameMode, sizeof(gameMode));
    
    if(StrEqual(gameMode, "survival", false))
        return 3;
    else if(StrEqual(gameMode, "versus", false) || StrEqual(gameMode, "teamversus", false) || 
            StrEqual(gameMode, "scavenge", false) || StrEqual(gameMode, "teamscavenge", false))
        return 2;
    else if(StrEqual(gameMode, "coop", false) || StrEqual(gameMode, "realism", false))
        return 1;
    
    return 0;
}

bool IsValidClient(int client)
{
    return (client > 0 && client <= MaxClients && IsClientInGame(client));
}